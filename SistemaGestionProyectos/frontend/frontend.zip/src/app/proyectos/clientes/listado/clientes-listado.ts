import { Component, effect, inject, model, ModelSignal, signal, OnInit, WritableSignal } from '@angular/core';
import { MessageService } from 'primeng/api';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { ClientesListadoApiClient } from './clientes-listado-api-client';
import { ListClienteDTO } from './list-cliente-dto';
import { DialogModule } from 'primeng/dialog';
import { GestionCliente } from '../gestion/gestion-cliente';

@Component({
    selector: "app-clientes-listado",
    templateUrl: "./clientes-listado.html",
    styleUrls: ["./clientes-listado.css"],
    imports: [DialogModule, ButtonModule, TableModule, GestionCliente]
})

export class ClientesListado implements OnInit{

    private readonly messageService: MessageService = inject(MessageService);
    private readonly clientesListadoApiClient: ClientesListadoApiClient = inject(ClientesListadoApiClient);

    visible: ModelSignal<boolean> = model(false);
    clientes: WritableSignal<ListClienteDTO[]> = signal([]);
    dialogVisible: WritableSignal<boolean> = signal(false);
    clienteSeleccionado: WritableSignal<ListClienteDTO | null> = signal<ListClienteDTO | null>(null);

    constructor() {

        effect(() => {
            if(!this.dialogVisible()){
                this.refrescarClientes()
            }
        });
    }

    ngOnInit(): void{
        this.refrescarClientes()
    };

    refrescarClientes(): void{
        this.clientesListadoApiClient.buscarClientes().subscribe({
            next: (data) => {
                this.clientes.set(data);
            },
            error: (err) => {
                this.messageService.add({severity: 'error', summary: 'Error', detail: 'Ocurrió un error al obtener los clientes'});
            }
        });
    }

    crearCliente(): void {
        this.dialogVisible.set(true);
    };

    editarCliente(cliente: ListClienteDTO): void {
        this.dialogVisible.set(true);
        this.clienteSeleccionado.set(cliente);
    }

    abrirDialog(): void{
        this.dialogVisible.set(true);
    }
    
}
